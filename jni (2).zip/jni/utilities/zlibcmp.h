#ifndef ZLIBCMP_H
#define ZLIBCMP_H

int def(FILE *source, FILE *dest, int level);
int inf(FILE *source, FILE *dest);

#endif
