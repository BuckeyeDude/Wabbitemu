#ifndef FTP_H
#define FTP_H

HINTERNET OpenFtpConnection();

#endif